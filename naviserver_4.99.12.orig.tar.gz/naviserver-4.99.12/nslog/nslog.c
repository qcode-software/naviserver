/*
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1(the "License"); you may not use this file except in
 * compliance with the License. You may obtain a copy of the License at
 * http://www.mozilla.org/.
 *
 * Software distributed under the License is distributed on an "AS IS"
 * basis,WITHOUT WARRANTY OF ANY KIND,either express or implied. See
 * the License for the specific language governing rights and limitations
 * under the License.
 *
 * The Original Code is AOLserver Code and related documentation
 * distributed by AOL.
 *
 * The Initial Developer of the Original Code is America Online,
 * Inc. Portions created by AOL are Copyright(C) 1999 America Online,
 * Inc. All Rights Reserved.
 *
 * Alternatively,the contents of this file may be used under the terms
 * of the GNU General Public License(the "GPL"),in which case the
 * provisions of GPL are applicable instead of those above.  If you wish
 * to allow use of your version of this file only under the terms of the
 * GPL and not to allow others to use your version of this file under the
 * License,indicate your decision by deleting the provisions above and
 * replace them with the notice and other provisions required by the GPL.
 * If you do not delete the provisions above,a recipient may use your
 * version of this file under either the License or the GPL.
 *
 */

/*
 * nslog.c --
 *
 *    Implements access logging in the NCSA Common Log format.
 *
 */

#include "ns.h"
#include <ctype.h>  /* isspace */

#define LOG_COMBINED      0x01u
#define LOG_FMTTIME       0x02u
#define LOG_REQTIME       0x04u
#define LOG_PARTIALTIMES  0x08u
#define LOG_CHECKFORPROXY 0x10u
#define LOG_SUPPRESSQUERY 0x20u

#if !defined(PIPE_BUF)
# define PIPE_BUF 512
#endif

NS_EXPORT const int Ns_ModuleVersion = 1;

typedef struct {
    Ns_Mutex     lock;
    const char  *module;
    const char  *file;
    const char  *rollfmt;
    const char **extheaders;
    int          numheaders;
    int          fd;
    unsigned int flags;
    int          maxbackup;
    int          maxlines;
    int          curlines;
    Ns_DString   buffer;
} Log;

/*
 * Local functions defined in this file
 */

static Ns_Callback     LogRollCallback;
static Ns_ShutdownProc LogCloseCallback;
static Ns_TraceProc    LogTrace;
static Ns_ArgProc      LogArg;
static Ns_TclTraceProc AddCmds;
static Tcl_ObjCmdProc  LogObjCmd;

NS_EXPORT Ns_ModuleInitProc Ns_ModuleInit;

static Ns_ReturnCode LogFlush(Log *logPtr, Ns_DString *dsPtr);
static Ns_ReturnCode LogOpen (Log *logPtr);
static Ns_ReturnCode LogRoll (Log *logPtr);
static Ns_ReturnCode LogClose(Log *logPtr);

static void AppendEscaped(Ns_DString *dsPtr, const char *chars)
    NS_GNUC_NONNULL(1) NS_GNUC_NONNULL(2);




/*
 *----------------------------------------------------------------------
 *
 * Ns_ModuleInit --
 *
 *      Module initialization routine.
 *
 * Results:
 *      NS_OK.
 *
 * Side effects:
 *      Log file is opened, trace routine is registered, and, if
 *      configured, log file roll signal and scheduled procedures
 *      are registered.
 *
 *----------------------------------------------------------------------
 */

NS_EXPORT Ns_ReturnCode
Ns_ModuleInit(const char *server, const char *module)
{
    const char   *path, *file;
    Log          *logPtr;
    Ns_DString    ds;
    static bool   first = NS_TRUE;
    Ns_ReturnCode result;

    NS_NONNULL_ASSERT(module != NULL);

    /*
     * Register the info callbacks just once. This assumes we are
     * called w/o locking from within the server startup.
     */

    if (first) {
        first = NS_FALSE;
        Ns_RegisterProcInfo((Ns_Callback *)LogRollCallback, "nslog:roll", LogArg);
        Ns_RegisterProcInfo((Ns_Callback *)LogCloseCallback, "nslog:close", LogArg);
        Ns_RegisterProcInfo((Ns_Callback *)LogTrace, "nslog:conntrace", LogArg);
        Ns_RegisterProcInfo((Ns_Callback *)AddCmds, "nslog:initinterp", LogArg);
    }

    Ns_DStringInit(&ds);

    logPtr = ns_calloc(1u, sizeof(Log));
    logPtr->module = module;
    logPtr->fd = NS_INVALID_FD;
    Ns_MutexInit(&logPtr->lock);
    Ns_MutexSetName2(&logPtr->lock, "nslog", server);
    Ns_DStringInit(&logPtr->buffer);

    path = Ns_ConfigGetPath(server, module, (char *)0);

    /*
     * Determine the name of the log file
     */

    file = Ns_ConfigString(path, "file", "access.log");
    if (Ns_PathIsAbsolute(file) == NS_TRUE) {
        logPtr->file = ns_strdup(file);
    } else {
        /*
         * If log file is not given in absolute format, it's expected to
         * exist in the global logs directory if such exists or module
         * specific directory, which is created if necessary.
         */

        if (Ns_HomePathExists("logs", (char *)0)) {
            (void) Ns_HomePath(&ds, "logs", "/", file, NULL);
        } else {
            Tcl_Obj *dirpath;
	    int rc;

            Ns_DStringTrunc(&ds, 0);
            (void) Ns_ModulePath(&ds, server, module, NULL, (char *)0);
            dirpath = Tcl_NewStringObj(ds.string, -1);
            Tcl_IncrRefCount(dirpath);
            rc = Tcl_FSCreateDirectory(dirpath);
            Tcl_DecrRefCount(dirpath);
            if (rc != TCL_OK && Tcl_GetErrno() != EEXIST && Tcl_GetErrno() != EISDIR) {
                Ns_Log(Error, "nslog: create directory (%s) failed: '%s'",
                       ds.string, strerror(Tcl_GetErrno()));
                Ns_DStringFree(&ds);
                return NS_ERROR;
            }
            Ns_DStringTrunc(&ds, 0);
            (void) Ns_ModulePath(&ds, server, module, file, (char *)0);
        }
        logPtr->file = Ns_DStringExport(&ds);
    }

    /*
     * Get other parameters from configuration file
     */

    logPtr->rollfmt = ns_strcopy(Ns_ConfigGetValue(path, "rollfmt"));
    logPtr->maxbackup = Ns_ConfigIntRange(path, "maxbackup", 100, 1, INT_MAX);
    logPtr->maxlines = Ns_ConfigIntRange(path, "maxbuffer", 0, 0, INT_MAX);
    if (Ns_ConfigBool(path, "formattedtime", NS_TRUE)) {
        logPtr->flags |= LOG_FMTTIME;
    }
    if (Ns_ConfigBool(path, "logcombined", NS_TRUE)) {
        logPtr->flags |= LOG_COMBINED;
    }
    if (Ns_ConfigBool(path, "logreqtime", NS_FALSE)) {
        logPtr->flags |= LOG_REQTIME;
    }
    if (Ns_ConfigBool(path, "logpartialtimes", NS_FALSE)) {
        logPtr->flags |= LOG_PARTIALTIMES;
    }
    if (Ns_ConfigBool(path, "suppressquery", NS_FALSE)) {
        logPtr->flags |= LOG_SUPPRESSQUERY;
    }
    if (Ns_ConfigBool(path, "checkforproxy", NS_FALSE)) {
        logPtr->flags |= LOG_CHECKFORPROXY;
    }

    /*
     *  Schedule various log roll and shutdown options.
     */

    if (Ns_ConfigBool(path, "rolllog", NS_TRUE)) {
        int hour = Ns_ConfigIntRange(path, "rollhour", 0, 0, 23);
        Ns_ScheduleDaily((Ns_SchedProc *) LogRollCallback, logPtr,
                         0, hour, 0, NULL);
    }
    if (Ns_ConfigBool(path, "rollonsignal", NS_FALSE)) {
        Ns_RegisterAtSignal(LogRollCallback, logPtr);
    }

    /*
     * Parse extended headers; it is just a list of names
     */

    Ns_DStringInit(&ds);
    Ns_DStringVarAppend(&ds, Ns_ConfigGetValue(path, "extendedheaders"), NULL);
    if (Tcl_SplitList(NULL, ds.string, &logPtr->numheaders,
                      &logPtr->extheaders) != TCL_OK) {
        Ns_Log(Error, "nslog: invalid %s/extendedHeaders parameter: '%s'",
               path, ds.string);
    }
    Ns_DStringFree(&ds);

    /*
     *  Open the log and register the trace
     */

    if (LogOpen(logPtr) != NS_OK) {
        return NS_ERROR;
    }

    Ns_RegisterServerTrace(server, LogTrace, logPtr);
    Ns_RegisterAtShutdown(LogCloseCallback, logPtr);
    result = Ns_TclRegisterTrace(server, AddCmds, logPtr, NS_TCL_TRACE_CREATE);

    return result;
}

static int
AddCmds(Tcl_Interp *interp, const void *arg)
{
    const Log *logPtr = arg;

    Tcl_CreateObjCommand(interp, "ns_accesslog", LogObjCmd, (ClientData)logPtr, NULL);
    return NS_OK;
}


/*
 *----------------------------------------------------------------------
 *
 * LogObjCmd --
 *
 *      Implement the ns_accesslog command.
 *
 * Results:
 *      Standard Tcl result.
 *
 * Side effects:
 *      Depends on command.
 *
 *----------------------------------------------------------------------
 */

static int
LogObjCmd(ClientData clientData, Tcl_Interp *interp, int objc, Tcl_Obj *CONST* objv)
{
    const char    *strarg, **hdrs;
    int            rc, intarg, cmd;
    Ns_DString     ds;
    Log           *logPtr = clientData;

    enum {
        ROLLFMT, MAXBACKUP, MAXBUFFER, EXTHDRS,
        FLAGS, FILE, ROLL
    };
    static const char *const subcmd[] = {
        "rollfmt", "maxbackup", "maxbuffer", "extendedheaders",
        "flags", "file", "roll", NULL
    };

    if (objc < 2) {
        Tcl_WrongNumArgs(interp, 1, objv, "option ?arg ...?");
        return TCL_ERROR;
    }
    rc = Tcl_GetIndexFromObj(interp, objv[1], subcmd, "option", 0, &cmd);
    if (rc != TCL_OK) {
        return TCL_ERROR;
    }

    switch (cmd) {
    case ROLLFMT:
        Ns_MutexLock(&logPtr->lock);
        if (objc > 2) {
            strarg = ns_strdup(Tcl_GetString(objv[2]));
            if (logPtr->rollfmt != NULL) {
                ns_free((char *)logPtr->rollfmt);
            }
            logPtr->rollfmt = strarg;
        }
        strarg = logPtr->rollfmt;
        Ns_MutexUnlock(&logPtr->lock);
        if (strarg != NULL) {
            Tcl_SetObjResult(interp, Tcl_NewStringObj(strarg, -1));
        }
        break;

    case MAXBACKUP:
        if (objc > 2) {
            if (Tcl_GetIntFromObj(interp, objv[2], &intarg) != TCL_OK) {
                return TCL_ERROR;
            }
            if (intarg < 1) {
                intarg = 100;
            }
        }
        Ns_MutexLock(&logPtr->lock);
        if (objc > 2) {
            logPtr->maxbackup = intarg;
        } else {
            intarg = logPtr->maxbackup;
        }
        Ns_MutexUnlock(&logPtr->lock);
        Tcl_SetObjResult(interp, Tcl_NewIntObj(intarg));
        break;

    case MAXBUFFER:
        if (objc > 2) {
            if (Tcl_GetIntFromObj(interp, objv[2], &intarg) != TCL_OK) {
                return TCL_ERROR;
            }
            if (intarg < 0) {
                intarg = 0;
            }
        }
        Ns_MutexLock(&logPtr->lock);
        if (objc > 2) {
            logPtr->maxlines = intarg;
        } else {
            intarg = logPtr->maxlines;
        }
        Ns_MutexUnlock(&logPtr->lock);
        Tcl_SetObjResult(interp, Tcl_NewIntObj(intarg));
        break;

    case EXTHDRS:
        {
            int n;
            if (objc > 2) {
                strarg = Tcl_GetString(objv[2]);
                if (Tcl_SplitList(interp, strarg, &n, &hdrs) != TCL_OK) {
                    return TCL_ERROR;
                }
            }
            Ns_MutexLock(&logPtr->lock);
            if (objc > 2) {
                if (logPtr->extheaders != NULL) {
                    Tcl_Free((char*)logPtr->extheaders);
                }
                logPtr->extheaders = hdrs;
                logPtr->numheaders = n;
            }
            strarg = Tcl_Merge(logPtr->numheaders, logPtr->extheaders);
            Ns_MutexUnlock(&logPtr->lock);
            Tcl_SetObjResult(interp, Tcl_NewStringObj(strarg, -1));
        }
        break;

    case FLAGS:
        {
            unsigned int flags;
            
            Ns_DStringInit(&ds);
            if (objc > 2) {
                flags = 0u;
                Ns_DStringAppend(&ds, Tcl_GetString(objv[2]));
                Ns_StrToLower(ds.string);
                if (strstr(ds.string, "logcombined")) {
                    flags |= LOG_COMBINED;
                }
                if (strstr(ds.string, "formattedtime")) {
                    flags |= LOG_FMTTIME;
                }
                if (strstr(ds.string, "logreqtime")) {
                    flags |= LOG_REQTIME;
                }
                if (strstr(ds.string, "logpartialtimes")) {
                    flags |= LOG_PARTIALTIMES;
                }
                if (strstr(ds.string, "checkforproxy")) {
                    flags |= LOG_CHECKFORPROXY;
                }
                if (strstr(ds.string, "suppressquery")) {
                    flags |= LOG_SUPPRESSQUERY;
                }
                Ns_DStringTrunc(&ds, 0);
                Ns_MutexLock(&logPtr->lock);
                logPtr->flags = flags;
                Ns_MutexUnlock(&logPtr->lock);
            } else {
                Ns_MutexLock(&logPtr->lock);
                flags = logPtr->flags;
                Ns_MutexUnlock(&logPtr->lock);
            }
            if ((flags & LOG_COMBINED)) {
                Ns_DStringAppend(&ds, "logcombined ");
            }
            if ((flags & LOG_FMTTIME)) {
                Ns_DStringAppend(&ds, "formattedtime ");
            }
            if ((flags & LOG_REQTIME)) {
                Ns_DStringAppend(&ds, "logreqtime ");
            }
            if ((flags & LOG_PARTIALTIMES)) {
                Ns_DStringAppend(&ds, "logpartialtimes ");
            }
            if ((flags & LOG_CHECKFORPROXY)) {
                Ns_DStringAppend(&ds, "checkforproxy ");
            }
            if ((rc & LOG_SUPPRESSQUERY)) {
                Ns_DStringAppend(&ds, "suppressquery ");
            }
            Tcl_DStringResult(interp, &ds);
        }
        break;

    case FILE:
        if (objc > 2) {
            Ns_DStringInit(&ds);
            strarg = Tcl_GetString(objv[2]);
            if (Ns_PathIsAbsolute(strarg) == NS_FALSE) {
                Ns_HomePath(&ds, strarg, NULL);
                strarg = ds.string;
            }
            Ns_MutexLock(&logPtr->lock);
            LogClose(logPtr);
            ns_free((char *)logPtr->file);
            logPtr->file = ns_strdup(strarg);
            Ns_DStringFree(&ds);
            LogOpen(logPtr);
        } else {
            Ns_MutexLock(&logPtr->lock);
        }
        Tcl_SetObjResult(interp, Tcl_NewStringObj(logPtr->file, -1));
        Ns_MutexUnlock(&logPtr->lock);
        break;

    case ROLL:
        {
            Ns_ReturnCode status = NS_ERROR;
            
            Ns_MutexLock(&logPtr->lock);
            if (objc == 2) {
                status = LogRoll(logPtr);
            } else if (objc > 2) {
                strarg = Tcl_GetString(objv[2]);
                if (Tcl_FSAccess(objv[2], F_OK) == 0) {
                    status = Ns_RollFile(strarg, logPtr->maxbackup);
                } else {
                    Tcl_Obj *path = Tcl_NewStringObj(logPtr->file, -1);
                    
                    Tcl_IncrRefCount(path);
                    rc = Tcl_FSRenameFile(path, objv[2]);
                    Tcl_DecrRefCount(path);
                    if (rc != 0) {
                        status = NS_ERROR;
                    } else {
                        LogFlush(logPtr, &logPtr->buffer);
                        status = LogOpen(logPtr);
                    }
                }
            }
            if (status != NS_OK) {
                Ns_TclPrintfResult(interp, "could not roll \"%s\": %s",
                                   logPtr->file, Tcl_PosixError(interp));
            }
            Ns_MutexUnlock(&logPtr->lock);
            if (status != NS_OK) {
                return TCL_ERROR;
            }
        }
        break;
    }

    return TCL_OK;
}

/*
 *----------------------------------------------------------------------
 *
 * AppendEscaped --
 *
 *	Append a string with escaped charaters
 *
 * Results:
 *	None.
 *
 * Side effects:
 *	updated dstring
 *
 *----------------------------------------------------------------------
 */

static void
AppendEscaped(Ns_DString *dsPtr, const char *chars)
{
    NS_NONNULL_ASSERT(dsPtr != NULL);
    NS_NONNULL_ASSERT(chars != NULL);
    
    while (likely(*chars != '\0')) {
        switch (*chars) {
        case '\n':
            Ns_DStringNAppend(dsPtr, "\\n", 2);
            break;

        case '\r':
            Ns_DStringNAppend(dsPtr, "\\r", 2);
            break;

        case '\t':
            Ns_DStringNAppend(dsPtr, "\\t", 2);
            break;

        case '"':
            Ns_DStringNAppend(dsPtr, "\\\"", 2);
            break;

	case '\\':
            Ns_DStringNAppend(dsPtr, "\\\\",2);
            break;

	default:
            Ns_DStringNAppend(dsPtr, chars, 1);
            break;
        }
        ++chars;
    }
}

/*
 *----------------------------------------------------------------------
 *
 * LogTrace --
 *
 *      Trace routine for appending the log with the current
 *      connection results.
 *
 * Results:
 *      None.
 *
 * Side effects:
 *      Entry is appended to the open log.
 *
 *----------------------------------------------------------------------
 */

static void
LogTrace(void *arg, Ns_Conn *conn)
{
    Log          *logPtr = arg;
    const char  **h, *user, *p;
    char          buffer[PIPE_BUF], *bufferPtr = NULL;
    int           n, i;
    Ns_ReturnCode status;
    size_t	  bufferSize = 0u;
    Ns_DString    ds, *dsPtr = &ds;

    Ns_DStringInit(dsPtr);
    Ns_MutexLock(&logPtr->lock);

    /*
     * Append the peer address. Watch for users coming
     * from proxy servers (if configured).
     */

    p = NULL;
    if ((logPtr->flags & LOG_CHECKFORPROXY)) {
        p = Ns_SetIGet(conn->headers, "X-Forwarded-For");
        if (p != NULL && !strcasecmp(p, "unknown")) {
            p = NULL;
        }
    }
    Ns_DStringAppend(dsPtr,
                     ((p != NULL) && (*p != '\0')) ?
                     p : Ns_ConnPeer(conn));

    /*
     * Append the authorized user, if any. Watch usernames
     * with embedded blanks; we must properly quote them.
     */

    user = Ns_ConnAuthUser(conn);
    if (user == NULL) {
        Ns_DStringNAppend(dsPtr, " - - ", 5);
    } else {
        int quote = 0;
        for (p = user; *p && !quote; p++) {
	    quote = (CHARTYPE(space, *p) != 0);
        }
        if (quote != 0) {
            Ns_DStringVarAppend(dsPtr, " - \"", user, "\" ", NULL);
        } else {
            Ns_DStringVarAppend(dsPtr, " - ", user, " ", NULL);
        }
    }

    /*
     * Append a common log format time stamp including GMT offset
     */

    if (!(logPtr->flags & LOG_FMTTIME)) {
        Ns_DStringPrintf(dsPtr, "[%" PRIu64 "]", (int64_t) time(NULL));
    } else {
        char buf[41]; /* Big enough for Ns_LogTime(). */
        Ns_LogTime(buf);
        Ns_DStringAppend(dsPtr, buf);
    }

    /*
     * Append the request line plus query data (if configured)
     */

    if (likely(conn->request.line != NULL)) {
	const char *string = (logPtr->flags & LOG_SUPPRESSQUERY) ? 
	    conn->request.url : 
	    conn->request.line;

	Ns_DStringNAppend(dsPtr, " \"", 2);
        if (likely(string != NULL)) {
            AppendEscaped(dsPtr, string);
        }
        Ns_DStringNAppend(dsPtr, "\" ", 2);

    } else {
        Ns_DStringNAppend(dsPtr, " \"\" ", 4);
    }

    /*
     * Construct and append the HTTP status code and bytes sent
     */

    n = Ns_ConnResponseStatus(conn);
    Ns_DStringPrintf(dsPtr, "%d %" PRIdz, (n != 0) ? n : 200, Ns_ConnContentSent(conn));

    /*
     * Append the referer and user-agent headers (if any)
     */

    if ((logPtr->flags & LOG_COMBINED)) {
        
        Ns_DStringNAppend(dsPtr, " \"", 2);
        p = Ns_SetIGet(conn->headers, "referer");
        if (p != NULL) {
            AppendEscaped(dsPtr, p);
        }
        Ns_DStringNAppend(dsPtr, "\" \"", 3);
        p = Ns_SetIGet(conn->headers, "user-agent");
        if (p != NULL) {
            AppendEscaped(dsPtr, p);
        }
        Ns_DStringNAppend(dsPtr, "\"", 1);
    }

    /*
     * Append the request's elapsed time and queue time (if enabled)
     */

    if ((logPtr->flags & LOG_REQTIME) != 0u) {
	Ns_Time reqTime, now;
	Ns_GetTime(&now);
        Ns_DiffTime(&now, Ns_ConnStartTime(conn), &reqTime);
        Ns_DStringNAppend(dsPtr, " ", 1);
	Ns_DStringAppendTime(dsPtr, &reqTime);

    }

    if ((logPtr->flags & LOG_PARTIALTIMES) != 0u) {
	Ns_Time  acceptTime, queueTime, filterTime, runTime;
        Ns_Time *startTimePtr =  Ns_ConnStartTime(conn);

	Ns_ConnTimeSpans(conn, &acceptTime, &queueTime, &filterTime, &runTime);

        Ns_DStringNAppend(dsPtr, " \"", 2);
        Ns_DStringAppendTime(dsPtr, startTimePtr);
        Ns_DStringNAppend(dsPtr, " ", 1);
        Ns_DStringAppendTime(dsPtr, &acceptTime);
        Ns_DStringNAppend(dsPtr, " ", 1);
        Ns_DStringAppendTime(dsPtr, &queueTime);
        Ns_DStringNAppend(dsPtr, " ", 1);
        Ns_DStringAppendTime(dsPtr, &filterTime);
        Ns_DStringNAppend(dsPtr, " ", 1);
        Ns_DStringAppendTime(dsPtr, &runTime);
        Ns_DStringNAppend(dsPtr, "\"", 1);
    }

    /*
     * Append the extended headers (if any)
     */

    for (h = logPtr->extheaders; *h != NULL; h++) {
        Ns_DStringNAppend(dsPtr, " \"", 2);
        p = Ns_SetIGet(conn->headers, *h);
        if (p != NULL) {
            AppendEscaped(dsPtr, p);
        }
        Ns_DStringNAppend(dsPtr, "\"", 1);
    }
    
    for (i = 0; i < ds.length; i++) {
        /* 
         * Quick fix to disallow terminal escape characters in the log
         * file. See e.g. http://www.securityfocus.com/bid/37712/info
         */
        if (unlikely(ds.string[i] == 0x1b)) {
            ds.string[i] = 7; /* bell */
        }
    }

    /*
     * Append the trailing newline and optionally
     * flush the buffer
     */

    Ns_DStringNAppend(dsPtr, "\n", 1);

    if (logPtr->maxlines == 0) {
        bufferSize = ds.length;
	if (bufferSize < PIPE_BUF) {
	  /* 
           * Only ns_write() operations < PIPE_BUF are guaranteed to be atomic
           */
	    bufferPtr = ds.string;
            status = NS_OK;
	} else {
	    status = LogFlush(logPtr, dsPtr);
	}
    } else {
        Ns_DStringNAppend(&logPtr->buffer, ds.string, ds.length);
        if (++logPtr->curlines > logPtr->maxlines) {
	    bufferSize = logPtr->buffer.length;
            if (bufferSize < PIPE_BUF) {
                /* 
                 * Only ns_write() operations < PIPE_BUF are guaranteed to be
                 * atomic.  In most cases, the other branch is used.
                 */
	      memcpy(buffer, logPtr->buffer.string, bufferSize);  
	      bufferPtr = buffer;
	      Ns_DStringTrunc(&logPtr->buffer, 0);
              status = NS_OK;
	    } else {
	      status = LogFlush(logPtr, &logPtr->buffer);
	    }
            logPtr->curlines = 0;
        } else {
            status = NS_OK;
        }
    }
    Ns_MutexUnlock(&logPtr->lock);

    (void)(status); /* ignore status */

    if (likely(bufferPtr != NULL) && likely(logPtr->fd >= 0) && likely(bufferSize > 0)) {
        (void)NsAsyncWrite(logPtr->fd, bufferPtr, bufferSize);
    }

    Ns_DStringFree(dsPtr);
}


/*
 *----------------------------------------------------------------------
 *
 * LogOpen --
 *
 *      Open the access log, closing previous log if opened.
 *      Assume caller is holding the log mutex.
 *
 * Results:
 *      NS_OK or NS_ERROR.
 *
 * Side effects:
 *      Log re-opened.
 *
 *----------------------------------------------------------------------
 */

static Ns_ReturnCode
LogOpen(Log *logPtr)
{
    int fd;

    fd = ns_open(logPtr->file, O_APPEND|O_WRONLY|O_CREAT, 0644);
    if (fd == NS_INVALID_FD) {
        Ns_Log(Error, "nslog: error '%s' opening '%s'",
               strerror(errno), logPtr->file);
        return NS_ERROR;
    }
    if (logPtr->fd >= 0) {
        ns_close(logPtr->fd);
    }

    logPtr->fd = fd;
    Ns_Log(Notice, "nslog: opened '%s'", logPtr->file);

    return NS_OK;
}


/*
 *----------------------------------------------------------------------
 *
 * LogClose --
 *
 *      Flush and/or close the log.
 *      Assume caller is holding the log mutex.
 *
 * Results:
 *      NS_TRUE or NS_FALSE if log was closed.
 *
 * Side effects:
 *      Buffer entries,if any,are flushed.
 *
 *----------------------------------------------------------------------
 */

static Ns_ReturnCode
LogClose(Log *logPtr)
{
    Ns_ReturnCode status = NS_OK;

    if (logPtr->fd >= 0) {
        status = LogFlush(logPtr, &logPtr->buffer);
        ns_close(logPtr->fd);
        logPtr->fd = NS_INVALID_FD;
        Ns_DStringFree(&logPtr->buffer);
        Ns_Log(Notice, "nslog: closed '%s'", logPtr->file);
    }

    return status;
}


/*
 *----------------------------------------------------------------------
 *
 * LogFlush --
 *
 *      Flush a log buffer to the open log file.
 *      Assume caller is holding the log mutex.
 *
 * Results:
 *      None.
 *
 * Side effects:
 *      Will disable the log on error.
 *
 *----------------------------------------------------------------------
 */

static Ns_ReturnCode
LogFlush(Log *logPtr, Ns_DString *dsPtr)
{
    int   len = dsPtr->length;
    char *buf = dsPtr->string;

    if (len > 0) {
        if (logPtr->fd >= 0 && ns_write(logPtr->fd, buf, len) != len) {
            Ns_Log(Error, "nslog: logging disabled: ns_write() failed: '%s'",
                   strerror(errno));
            ns_close(logPtr->fd);
            logPtr->fd = NS_INVALID_FD;
        }
        Ns_DStringTrunc(dsPtr, 0);
    }

    return (logPtr->fd == NS_INVALID_FD) ? NS_ERROR : NS_OK;
}


/*
 *----------------------------------------------------------------------
 *
 * LogRoll --
 *
 *      Roll and re-open the access log.  This procedure is scheduled
 *      and/or registered at signal catching.
 *
 *      Assume caller is holding the log mutex.
 *
 * Results:
 *      None.
 *
 * Side effects:
 *      Files are rolled to new names.
 *
 *----------------------------------------------------------------------
 */

static Ns_ReturnCode
LogRoll(Log *logPtr)
{
    Ns_ReturnCode status;
    Tcl_Obj      *path;

    NsAsyncWriterQueueDisable(NS_FALSE);

    (void)LogClose(logPtr);

    path = Tcl_NewStringObj(logPtr->file, -1);
    Tcl_IncrRefCount(path);
    status = Tcl_FSAccess(path, F_OK);

    if (status == 0) {

        /*
         * We are already logging to some file
         */

        if (logPtr->rollfmt == NULL) {
            status = Ns_RollFile(logPtr->file, logPtr->maxbackup);
        } else {
            time_t      now = time(NULL);
            char        timeBuf[512];
            Ns_DString  ds;
	    Tcl_Obj    *newpath;
            struct tm  *ptm;

            ptm = ns_localtime(&now);
            (void) strftime(timeBuf, sizeof(timeBuf)-1, logPtr->rollfmt, ptm);

            Ns_DStringInit(&ds);
            Ns_DStringVarAppend(&ds, logPtr->file, ".", timeBuf, NULL);
            newpath = Tcl_NewStringObj(ds.string, -1);
            Tcl_IncrRefCount(newpath);
            status = Tcl_FSAccess(newpath, F_OK);
            if (status == 0) {
                status = Ns_RollFile(ds.string, logPtr->maxbackup);
            } else if (Tcl_GetErrno() != ENOENT) {
                Ns_Log(Error, "nslog: access(%s, F_OK) failed: '%s'",
                       ds.string, strerror(Tcl_GetErrno()));
                status = NS_ERROR;
            } else {
		status = NS_OK;
	    }
            if (status == NS_OK && Tcl_FSRenameFile(path, newpath)) {
                Ns_Log(Error, "nslog: rename(%s,%s) failed: '%s'",
                       logPtr->file, ds.string, strerror(Tcl_GetErrno()));
                status = NS_ERROR;
            }
            Tcl_DecrRefCount(newpath);
            Ns_DStringFree(&ds);
            if (status == NS_OK) {
                status = Ns_PurgeFiles(logPtr->file, logPtr->maxbackup);
            }
        }
    }

    Tcl_DecrRefCount(path);
    
    if (status == NS_OK) {
	status = LogOpen(logPtr);
    }
    NsAsyncWriterQueueEnable();

    return status;
}


/*
 *----------------------------------------------------------------------
 *
 * LogCloseCallback, LogRollCallback -
 *
 *      Close or roll the log.
 *
 * Results:
 *      None.
 *
 * Side effects:
 *      See LogClose and LogRoll.
 *
 *----------------------------------------------------------------------
 */

static void
LogCallback(int(proc)(Log *), void *arg, char *desc)
{
    int  status;
    Log *logPtr = arg;

    Ns_MutexLock(&logPtr->lock);
    status =(*proc)(logPtr);
    Ns_MutexUnlock(&logPtr->lock);

    if (status != NS_OK) {
        Ns_Log(Error, "nslog: failed: %s '%s': '%s'", desc, logPtr->file,
               strerror(Tcl_GetErrno()));
    }
}

static void
LogCloseCallback(const Ns_Time *toPtr, void *arg)
{
    if (toPtr == NULL) {
        LogCallback(LogClose, arg, "close");
    }
}

static void
LogRollCallback(void *arg)
{
    LogCallback(LogRoll, arg, "roll");
}


/*
 *----------------------------------------------------------------------
 *
 * LogArg --
 *
 *      Copy log file as argument for callback introspection queries.
 *
 * Results:
 *      None.
 *
 * Side effects:
 *      None.
 *
 *----------------------------------------------------------------------
 */

static void
LogArg(Tcl_DString *dsPtr, const void *arg)
{
    const Log *logPtr = arg;

    Tcl_DStringAppendElement(dsPtr, logPtr->file);
}

/*
 * Local Variables:
 * mode: c
 * c-basic-offset: 4
 * fill-column: 78
 * indent-tabs-mode: nil
 * End:
 */
